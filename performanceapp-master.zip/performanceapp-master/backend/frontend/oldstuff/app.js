/* adding function

Import dummy users
create functional conditions
create functional response to events


*/